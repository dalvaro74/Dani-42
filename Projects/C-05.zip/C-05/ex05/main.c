#include <stdio.h>
#include <string.h>

int		ft_sqrt(int nb);

int main (void)
{	
	int num = 7;
	
	printf("%d\n",ft_sqrt(num));
	
	return(0);
}