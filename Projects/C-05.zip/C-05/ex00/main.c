#include <stdio.h>
#include <string.h>

int		ft_iterative_factorial(int nb);

int main (void)
{	
	int num = 6;
	
	printf("%d\n",ft_iterative_factorial(num));
	
	return(num);
}