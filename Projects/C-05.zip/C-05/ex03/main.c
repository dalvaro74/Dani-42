#include <stdio.h>
#include <string.h>

int		ft_recursive_power(int nb, int power);

int main (void)
{	
	int num = 15;
	
	printf("%d\n",ft_recursive_power(0, 0));
	
	return(num);
}