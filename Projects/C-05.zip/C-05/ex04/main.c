#include <stdio.h>
#include <string.h>

int		ft_fibonacci(int index);

int main (void)
{	
	int num = 15;
	
	printf("%d\n",ft_fibonacci(2));
	
	return(num);
}