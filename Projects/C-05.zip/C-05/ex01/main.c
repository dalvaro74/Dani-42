#include <stdio.h>
#include <string.h>

int		ft_recursive_factorial(int nb);

int main (void)
{	
	int num = 5;
	
	printf("%d\n",ft_recursive_factorial(num));
	
	return(num);
}