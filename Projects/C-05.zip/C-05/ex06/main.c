#include <stdio.h>
#include <string.h>

int		ft_is_prime(int nb);

int main (void)
{	
	int num = 8;
	
	printf("%d\n",ft_is_prime(num));
	
	return(0);
}