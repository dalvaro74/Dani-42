#include <stdio.h>
#include <string.h>

int		ft_iterative_power(int nb, int power);

int main (void)
{	
	int num = 15;
	
	printf("%d\n",ft_iterative_power(0, 1));
	
	return(num);
}