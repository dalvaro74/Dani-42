#include <stdio.h>
#include <string.h>

void ft_putstr(char *str);

int main (void)
{	
	char str[] = "Foo Bar pepe hola";
	
	ft_putstr(str);
	
	return(0);
}